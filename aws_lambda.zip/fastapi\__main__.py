from fastapi.cli import main

main()
