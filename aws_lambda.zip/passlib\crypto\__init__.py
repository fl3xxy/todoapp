"""passlib.crypto -- package containing cryptographic primitives used by passlib"""
